<footer class="site-footer">
    <div class="footer-content">
        <p>Sistema de Gestión Bibliotecaria - Practica Profesionalizante I</p>
        <p>&copy; <?php echo date('Y'); ?> Todos los derechos reservados</p>
    </div>
</footer>

<style>
.site-footer {
    background-color: #f8f9fa;
    padding: 20px 0;
    margin-top: 30px;
    border-top: 1px solid #e7e7e7;
    text-align: center;
    font-size: 14px;
    color: #555;
}

.footer-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 15px;
}
</style>