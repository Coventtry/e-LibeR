<?php
header('Content-Type: application/json');

try {
    require 'conectatew.php';
    
    // 2. Recibir y validar datos
    $data = json_decode(file_get_contents('php://input'), true);
    $email = filter_var($data['email'], FILTER_VALIDATE_EMAIL);
    if (!$email) throw new Exception("Email no válido");
    
    // 3. Registrar notificación
    $stmt = $pdo->prepare("
        INSERT INTO notificaciones (prestamo_id, email, material, fecha_devolucion, fecha_envio)
        VALUES (:prestamo_id, :email, :material, :devolucion, datetime('now'))
    ");
    $stmt->execute([
        ':prestamo_id' => $data['prestamo_id'],
        ':email' => $email,
        ':material' => $data['material'],
        ':devolucion' => $data['devolucion']
    ]);
    
    // 4. Enviar email (ejemplo básico)
    $asunto = "Recordatorio de devolución: " . $data['material'];
    $mensaje = sprintf(
        "Estimado socio,\n\nEl material \"%s\" debe ser devuelto antes del %s.\n\nAtentamente,\nBiblioteca",
        $data['material'],
        $data['devolucion']
    );
    
    $headers = "From: biblioteca@tudominio.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8";
    
    if (mail($email, $asunto, $mensaje, $headers)) {
        echo json_encode(['success' => true]);
    } else {
        throw new Exception("Error al enviar correo");
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>