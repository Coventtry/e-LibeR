<?php
try {
    $conn = new PDO('mysql:host=localhost;dbname=biblioteca', 'ENDRIZZI', 'Je_311098');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>