<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $nombre = $_POST["nombre"];
    $material = $_POST["material"];
    $fecha_devolucion = $_POST["fecha_devolucion"];

    // Asunto y mensaje
    $asunto = "📚 Recordatorio de devolución - Biblioteca";
    $mensaje = "
        Estimado/a $nombre,

        Le recordamos que debe devolver el material bibliográfico:
        \"$material\"

        Fecha límite de devolución: $fecha_devolucion.

        Por favor, acérquese a la biblioteca lo antes posible para regularizar el préstamo.

        Muchas gracias.

        Atentamente,
        Biblioteca Escolar
    ";

    // Cabeceras del correo
    $cabeceras = "From: biblioteca@tuinstitucion.edu.ar\r\n";
    $cabeceras .= "Reply-To: biblioteca@tuinstitucion.edu.ar\r\n";
    $cabeceras .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Enviar el email
    if (mail($email, $asunto, $mensaje, $cabeceras)) {
        echo "<script>alert('📧 Recordatorio enviado a $email'); window.history.back();</script>";
    } else {
        echo "<script>alert('❌ Error al enviar el recordatorio.'); window.history.back();</script>";
    }
} else {
    echo "Acceso no permitido.";
}
?>
