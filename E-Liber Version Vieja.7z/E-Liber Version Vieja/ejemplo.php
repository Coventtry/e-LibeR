<?php
$conexion = new mysqli("localhost", "root", "", "biblioteca");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$id_socio = $_POST['socio_id'];
$id_material = $_POST['material_id'];
$fecha_prestamo = date("Y-m-d");
$fecha_devolucion = $_POST['fecha_devolucion'];
$estado = "Pendiente";

// Insertar nuevo préstamo
$sql = "INSERT INTO prestamos (socio_id, id_material, fecha_prestamo, fecha_devolucion, estado)
        VALUES ('$id_socio', '$id_material', '$fecha_prestamo', '$fecha_devolucion', '$estado')";

if ($conexion->query($sql) === TRUE) {
    // Actualizar el estado del material
    $update_material = "UPDATE materiales SET estado = 'Prestado' WHERE id = '$id_material'";
    $conexion->query($update_material);

    echo "Préstamo registrado y material marcado como prestado.";
} else {
    echo "Error al registrar préstamo: " . $conexion->error;
}

$conexion->close();
?>
