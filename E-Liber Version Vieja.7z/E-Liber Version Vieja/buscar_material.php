<?php
require 'CONECTOR.PHP'; // Incluir conexión a SQLite

// Variable para los resultados
$result = null;

// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['buscar'])) {
    $buscar = trim($_POST['buscar']);
    $tipo_busqueda = $_POST['tipo_busqueda'];

    $buscar_inicial = $buscar . '%';
    $buscar_general = '%' . $buscar . '%';

    try {
        if ($tipo_busqueda == 'titulo') {
            $sql = "SELECT id, titulo, autor, anio_publicacion, categoria, area_id, disponibilidad
                    FROM materiales 
                    WHERE titulo LIKE :busqueda_exacto OR titulo LIKE :busqueda_parcial
                    ORDER BY titulo ASC";
        } elseif ($tipo_busqueda == 'categoria') {
            $sql = "SELECT id, titulo, autor, anio_publicacion, categoria, area_id, disponibilidad
                    FROM materiales 
                    WHERE categoria LIKE :busqueda_exacto OR categoria LIKE :busqueda_parcial
                    ORDER BY categoria ASC";
        }

        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':busqueda_exacto', $buscar_inicial, PDO::PARAM_STR);
        $stmt->bindValue(':busqueda_parcial', $buscar_general, PDO::PARAM_STR);
        $stmt->execute();

        $datos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Agrupar por título para detectar duplicados
        $agrupados = [];
        foreach ($datos as $row) {
            $titulo = $row['titulo'];
            if (!isset($agrupados[$titulo])) {
                $agrupados[$titulo] = [];
            }
            $agrupados[$titulo][] = $row;
        }
        $result = $agrupados;

    } catch (PDOException $e) {
        echo "Error en la consulta: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <?php include 'icono.php'; ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Libro</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .result {
            margin-top: 20px;
            background: #e9ecef;
            padding: 10px;
            border-radius: 4px;
        }
        .duplicado {
            margin-left: 20px;
            background-color: #fff;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        footer {
            margin-top: 28%;
            background-color: #052442;
            color: white;
            padding: 10px;
            text-align: center;
        }
        h6 {
            color: white;
        }
        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #6c757d;
            text-decoration: none;
            font-size: 1.1rem;
        }
        a:hover {
            color: #218838;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Buscar Libro</h1>
        <form method="POST" action="">
            <label for="buscar">Buscar por:</label>
            <input type="text" name="buscar" id="buscar" placeholder="Ingrese título o categoría" required>
            
            <label for="tipo_busqueda">Seleccione el tipo de búsqueda:</label>
            <select name="tipo_busqueda" id="tipo_busqueda" required>
                <option value="titulo">Título</option>
                <option value="categoria">Categoría</option>
            </select>

            <input type="submit" value="Buscar">
        </form>

        <?php if ($result !== null): ?>
            <div class="result">
                <?php if (count($result) > 0): ?>
                    <?php foreach ($result as $titulo => $libros): ?>
                        <?php if (count($libros) > 1): ?>
                            <strong><?= htmlspecialchars($titulo) ?></strong> (<?= count($libros) ?> coincidencias):<br>
                            <?php foreach ($libros as $libro): ?>
                                <div class="duplicado">
                                    Autor: <?= htmlspecialchars($libro['autor']) ?><br>
                                    Año: <?= htmlspecialchars($libro['anio_publicacion']) ?><br>
                                    Categoría: <?= htmlspecialchars($libro['categoria']) ?><br>
                                    Área ID: <?= htmlspecialchars($libro['area_id']) ?><br>
                                    Disponibilidad: <?= htmlspecialchars($libro['disponibilidad']) ?><br>
                                </div>
                            <?php endforeach; ?>
                            <hr>
                        <?php else: ?>
                            <?php $libro = $libros[0]; ?>
                            <strong>Título:</strong> <?= htmlspecialchars($libro['titulo']) ?><br>
                            Autor: <?= htmlspecialchars($libro['autor']) ?><br>
                            Año: <?= htmlspecialchars($libro['anio_publicacion']) ?><br>
                            Categoría: <?= htmlspecialchars($libro['categoria']) ?><br>
                            Área ID: <?= htmlspecialchars($libro['area_id']) ?><br>
                            Disponibilidad: <?= htmlspecialchars($libro['disponibilidad']) ?><br><hr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No se encontraron libros que coincidan con el criterio de búsqueda.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <a href="ingreso_bibliotecario.php">Volver a la página principal</a>

    <footer class="footer">
        <h6>Practica Profesionalizante I</h6>
        <h6>Esta página fue desarrollada utilizando HTML 5, CSS, Bootstrap 5, PHP</h6>
    </footer>

</body>
</html>
