<?php
$id_socio = $_POST['id_socio'];
// Aquí deberías hacer una consulta para obtener el email del socio
// Simulamos email:
$to = "socio@example.com";
$subject = "Información sobre su estado";
$message = "Estimado socio, se ha registrado un cambio en su estado. Por favor comuníquese para más detalles.";
$headers = "From: biblioteca@institucion.com";

mail($to, $subject, $message, $headers);

echo "Correo enviado exitosamente.";
?>
