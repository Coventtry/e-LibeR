<?php
require 'conexion_BD.php';  // conecta con la base de datos

try {
    $sql = "ALTER TABLE socios ADD COLUMN activo INTEGER DEFAULT 1;";
    $conn->exec($sql);  // ejecuta la consulta
    echo "Columna 'activo' agregada correctamente.";
} catch (PDOException $e) {
    echo "Error al agregar la columna: " . $e->getMessage();
}
?>
