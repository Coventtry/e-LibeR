<?php
session_start();
require 'conexion_BD.php';

// Redirigir al login si no hay sesión activa
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <link rel="icon" href="img/icono.ico" type="image/x-icon">
  <title>e-LibeR - I.E.S. - ESCUELA NORMAL SUPERIOR "GENERAL MANUEL BELGRANO"</title>
  <?php include 'encabezado.html'; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body, html {
      height: 100%;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
    }

    .jumbotron {
      background: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 1)),
                  url('img/biblioadmin.webp');
      background-size: cover;
      background-position: center;
      color: white;
      height: 300px;
      margin-bottom: 0;
    }

    .navbar-nav {
      margin-left: auto;
      margin-right: auto;
      text-align: center;
    }

    .navbar .navbar-collapse {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .navbar {
      position: relative;
      z-index: 10;
      margin-bottom: 0;
    }

    .content {
      flex: 1;
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      padding-top: 0;
    }

    .content img {
      max-width: 100%;
      height: auto;
      flex-grow: 1;
    }

    .calendar-wrapper {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: rgba(255, 255, 255, 0.7);
      padding: 20px;
      border-radius: 10px;
      z-index: 1;
    }

    iframe {
      border: 0;
      width: 600px;
      height: 400px;
      border-radius: 10px;
    }

    footer {
      background-color: #052442;
      color: white;
      padding: 10px;
      text-align: center;
      margin-top: 0;
    }

    hr {
      border: 0;
      height: 20px;
      background-color: white;
      width: 2px;
      margin: 12px 0;
    }

    .disabled-link {
      pointer-events: none;
      color: grey;
    }
  </style>
</head>
<body>

<div class="jumbotron text-center" style="margin-bottom:0">
  <img src="img/logo.png" alt="Bibliotecario" width="400" height="120">
  <h4 style="margin-top: 20px;"><u>ADMINISTRACION DE BIBLIOTECA</u></h4>
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <img src="img/login.png" alt="Bibliotecario" width="60" height="60">
    <h6 style="display:inline; margin-left:23px; color:white">
      <?php echo $_SESSION['usuario']; ?>
    </h6>
    <ul class="navbar-nav">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Socio</a>
        <div class="dropdown-menu">
        <!--<a class="dropdown-item" href="socio.html">Buscar</a>-->
          <a class="dropdown-item" href="agregarsocio.html">Nuevo</a>
          <!--<a class="dropdown-item" href="UNIFICADO_SOCIOS.php">Modificar</a>-->
          <a class="dropdown-item" href="modificar_socio.php">Buscar/Modificar</a>
          <a class="dropdown-item" href="baja_socio.php">Eliminar</a>
        </div>
      </li>
      <hr>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Materiales</a>
        <div class="dropdown-menu">
                <!--SE BORRA BUSCAR LIBROS YA QUE ESTA MODIFICAR LIBROS COMO BUSCADOR -->
          <a class="dropdown-item" href="agregar_material.php">Nuevo </a>
          <a class="dropdown-item" href="unificado.php">Modificar/ Buscar</a>
          <a class="dropdown-item" href="LISTA_MATERIALES.php">LISTA DE MATERIALES </a>
          <a class="dropdown-item" href="eliminar_material.php">Eliminar</a>
          <a class="dropdown-item" href="CONTEMOS.php">3</a>
        </div>
      </li>
      <hr>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Áreas</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="cargar_area.php">Nuevo</a>
          <a class="dropdown-item" href="modificar_area.php">Modificar</a>
          <a class="dropdown-item" href="eliminar_area.php">Eliminar</a>
        </div>
      </li>
      <hr>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Avisador</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="noticia.php">Cargar</a>
          <a class="dropdown-item" href="avisador.php">Modificar/eliminar</a>
        </div>
      </li>
      <hr>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Prestamos</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="prestamo.php">Nuevo</a>
          <a class="dropdown-item" href="Devolvamos_juntos.php">Listado/Devolución</a>
        </div>
      </li>
      <hr>
      <li class="nav-item">
        <a class="nav-link" href="carga_material.php">Código</a>
      </li>
      <hr>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" style="color:green" href="#" data-toggle="dropdown">NOTAS</a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="crear_nota.php">Crear Nota</a>
          <a class="dropdown-item" href="consultar_nota.php">Consultar notas</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" style="color:red;" href="logout.php">Cerrar Sesión</a>
      </li>
    </ul>
  </div>
</nav>

<div class="content">
  <img src="img/imagen13.jpg" alt="Imagen de fondo">
  <div class="calendar-wrapper">
    <!-- Calendario FUNCIONAL -->
    <iframe src="https://calendar.google.com/calendar/embed?src=your_calendar_id&ctz=America%2FNew_York" 
frameborder="0" scrolling="no"></iframe>

  </div>
</div>

<?php require 'ALERTA_PRESTAMO.PHP'; ?>

<footer>
  <?php include 'footer.html'; ?>
</footer>

</body>
</html>
