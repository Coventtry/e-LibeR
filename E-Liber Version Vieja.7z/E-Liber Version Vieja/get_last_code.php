<?php
require 'CONECTOR.PHP'; // Asegúrate que esta ruta es correcta

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['area_id'])) {
    $area_id = (int)$_POST['area_id'];

    try {
        // Buscar el último código para esa área
        $stmt = $conn->prepare("SELECT codigo FROM materiales WHERE area_id = :area_id ORDER BY id DESC LIMIT 1");
        $stmt->bindParam(':area_id', $area_id, PDO::PARAM_INT);
        $stmt->execute();
        $lastMaterial = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($lastMaterial && preg_match('/-(\d+)$/', $lastMaterial['codigo'], $matches)) {
            $lastNumber = (int)$matches[1];
        } else {
            $lastNumber = 0;
        }

        echo json_encode([
            'success' => true,
            'last_number' => $lastNumber
        ]);
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Error de base de datos: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Solicitud no válida.'
    ]);
}
?>
