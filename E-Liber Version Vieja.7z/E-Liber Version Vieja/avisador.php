<?php
require 'conectatew.php'; // archivo con PDO y SQLite

// Consultar las noticias
$stmt = $pdo->prepare("SELECT id, titulo, descripcion, imagen FROM noticias ORDER BY id DESC");
$stmt->execute();
$noticias = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<!-- (Tu código de head aquí, sin cambios) -->
<link rel="icon" href="img/icono.ico" type="image/x-icon">
<title>Avisador de Noticias</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<style>
/* Tu CSS aquí (igual que antes) */
</style>
</head>
<body>
<h1>Noticias</h1>
<div class="container">
    <div class="row">
        <?php
        if(count($noticias) > 0) {
            foreach($noticias as $row) {
                echo '<div class="col-md-4 mb-4">';
                echo '<div class="news-container">';
                echo '<h3 class="news-title">' . htmlspecialchars($row["titulo"]) . '</h3>';
                echo '<img src="' . htmlspecialchars($row["imagen"]) . '" alt="Noticia" class="img-fluid mb-3 rounded">';
                echo '<p class="news-description">' . htmlspecialchars($row["descripcion"]) . '</p>';

                // Botón para modificar
                echo '<form action="modifcar_avisador.php" method="POST">';
                echo '<input type="hidden" name="id" value="' . htmlspecialchars($row["id"]) . '">';
                echo '<button type="submit" class="btn btn-edit">Modificar</button>';
                echo '</form>';

                // Botón para eliminar
                echo '<form action="eliminar_avisador.php" method="POST" onsubmit="return confirm(\'¿Estás seguro de que quieres eliminar esta noticia?\');">';
                echo '<input type="hidden" name="id" value="' . htmlspecialchars($row["id"]) . '">';
                echo '<button type="submit" class="btn btn-delete">Eliminar</button>';
                echo '</form>';

                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "<p class='text-center'>No hay noticias disponibles.</p>";
        }
        ?>
    </div>
</div>
<a href="ingreso_bibliotecario.php" class="back-link">Volver a la página principal</a>

<!-- Footer -->
<footer>
    <h6>Práctica Profesionalizante I</h6>
    <p>Esta página fue desarrollada utilizando HTML 5, CSS, PHP</p>
</footer>
</body>
</html>
